export const DEVICE_METER_TYPES = {
  ELECTRIC: "ELECTRIC",
  WATER: "WATER",
};

export const DRAWER_MODES = {
  VIEW: "VIEW",
  CREATE: "CREATE",
  UPDATE: "UPDATE",
};
